class ChatModel {
  final String title;
  final String subtitle;

  ChatModel(this.title, this.subtitle);
}

List<ChatModel> chatapp = [
  ChatModel('Louis', 'hey there'),
  ChatModel('Andrea', 'sent you a photo'),
  ChatModel('Jacob', 'are u free?'),
  ChatModel('Nicolas', 'how r u'),
  ChatModel('Luca', 'all gud?'),
  ChatModel('Ana', 'hey there!!'),
  ChatModel('Madeline', 'when r u coming'),
  ChatModel('Eric', 'send the code'),
  ChatModel('Stephan', 'Hello'),
];
